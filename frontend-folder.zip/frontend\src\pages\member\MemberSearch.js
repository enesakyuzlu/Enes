import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Layout from "../../components/Layout";
import axios from "axios";
import { Search, MapPin, Clock, Bus, Tag } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const MemberSearch = ({ user, onLogout }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  
  const [cities, setCities] = useState([]);
  const [fromCity, setFromCity] = useState(params.get('from') || "");
  const [toCity, setToCity] = useState(params.get('to') || "");
  const [date, setDate] = useState(params.get('date') || "");
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    const fetchCities = async () => {
      try {
        const response = await axios.get(`${API}/cities`);
        setCities(response.data.cities);
      } catch (error) {
        console.error("Şehirler yüklenemedi:", error);
      }
    };
    fetchCities();

    // Auto search if params exist
    if (fromCity && toCity && date) {
      handleSearch();
    }
  }, []);

  const handleSearch = async (e) => {
    if (e) e.preventDefault();
    if (!fromCity || !toCity || !date) {
      alert("Lütfen tüm alanları doldurun");
      return;
    }

    setLoading(true);
    setSearched(true);
    try {
      const response = await axios.get(`${API}/trips/search`, {
        params: { from_city: fromCity, to_city: toCity, date }
      });
      setTrips(response.data.trips);
    } catch (error) {
      console.error("Sefer ara başarısız:", error);
      alert("Sefer arama sırasında hata oluştu");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-8">
        <h1 className="text-4xl font-bold text-white mb-8" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
          Sefer Arama
        </h1>

        {/* Search Form */}
        <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-6 mb-8" data-testid="search-widget">
          <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Nereden</label>
              <select 
                className="input-dark w-full" 
                value={fromCity} 
                onChange={(e) => setFromCity(e.target.value)}
                data-testid="from-city-select"
              >
                <option value="">Şehir Seçin</option>
                {cities.map((city) => (
                  <option key={city} value={city}>{city}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Nereye</label>
              <select 
                className="input-dark w-full" 
                value={toCity} 
                onChange={(e) => setToCity(e.target.value)}
                data-testid="to-city-select"
              >
                <option value="">Şehir Seçin</option>
                {cities.map((city) => (
                  <option key={city} value={city}>{city}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Tarih</label>
              <input 
                type="date" 
                className="input-dark w-full" 
                value={date} 
                onChange={(e) => setDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                data-testid="date-input"
              />
            </div>

            <div className="flex items-end">
              <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2" data-testid="search-btn">
                <Search className="w-5 h-5" />
                Ara
              </button>
            </div>
          </form>
        </div>

        {/* Results */}
        {loading ? (
          <div className="text-white/60 text-center py-12">Seferler aranıyor...</div>
        ) : searched && trips.length === 0 ? (
          <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 text-center text-white/60">
            Bu gün için sefer bulunamadı.
          </div>
        ) : (
          <div className="space-y-4">
            {trips.map((trip) => (
              <div 
                key={trip.id} 
                className="card-dark cursor-pointer" 
                onClick={() => navigate(`/member/trip/${trip.id}`)}
                data-testid={`trip-${trip.id}`}
              >
                <div className="flex flex-wrap justify-between items-start gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-3">
                      <Bus className="w-5 h-5 text-blue-500" />
                      <h3 className="text-lg font-bold text-white">{trip.company_name}</h3>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-white/60">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        <span>{trip.from_city} → {trip.to_city}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        <span>{trip.date} - {trip.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span>Boş Koltuk: {trip.available_seats.length}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    {trip.discount > 0 && (
                      <div className="flex items-center gap-2 mb-2">
                        <Tag className="w-4 h-4 text-green-500" />
                        <span className="text-green-500 font-bold text-sm">%{trip.discount} İndirim</span>
                      </div>
                    )}
                    <p className="text-3xl font-bold text-rose-500">{trip.discounted_price} TL</p>
                    {trip.discount > 0 && (
                      <p className="text-white/40 line-through text-sm">{trip.price} TL</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default MemberSearch;
