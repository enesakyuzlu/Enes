import { Link } from "react-router-dom";
import { LayoutDashboard, Bus, MapPin, Ticket } from "lucide-react";

const CompanySidebar = ({ active }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/company/dashboard' },
    { id: 'buses', label: 'Otobüsler', icon: Bus, path: '/company/buses' },
    { id: 'trips', label: 'Seferler', icon: MapPin, path: '/company/trips' },
    { id: 'reservations', label: 'Rezervasyonlar', icon: Ticket, path: '/company/reservations' },
  ];

  return (
    <div className="bg-[#1A1A1A] border-r border-white/10 min-h-screen w-64 p-6">
      <nav className="space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.id}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                active === item.id
                  ? 'bg-rose-600 text-white'
                  : 'text-white/60 hover:bg-white/5 hover:text-white'
              }`}
              data-testid={`menu-${item.id}`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
};

export default CompanySidebar;
