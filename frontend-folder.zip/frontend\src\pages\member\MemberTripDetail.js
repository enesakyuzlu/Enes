import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Layout from "../../components/Layout";
import axios from "axios";
import { ArrowLeft, Check } from "lucide-react";

// Aynı domain altında deploy edilince API'yi relative çağır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const MemberTripDetail = ({ user, onLogout }) => {
  const { tripId } = useParams();
  const navigate = useNavigate();
  const [trip, setTrip] = useState(null);
  const [bus, setBus] = useState(null);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTripDetails();
  }, [tripId]);

  const fetchTripDetails = async () => {
    try {
      const tripRes = await axios.get(`${API}/trips/${tripId}`);
      setTrip(tripRes.data);
      
      const busRes = await axios.get(`${API}/company/${tripRes.data.company_id}/buses`);
      const busData = busRes.data.find(b => b.id === tripRes.data.bus_id);
      setBus(busData);
    } catch (error) {
      console.error("Sefer detayları yüklenemedi:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleSeat = (seatNumber) => {
    if (!trip.available_seats.includes(seatNumber)) return;
    
    if (selectedSeats.includes(seatNumber)) {
      setSelectedSeats(selectedSeats.filter(s => s !== seatNumber));
    } else {
      setSelectedSeats([...selectedSeats, seatNumber]);
    }
  };

  const handleContinue = () => {
    if (selectedSeats.length === 0) {
      alert('Lütfen en az bir koltuk seçin');
      return;
    }
    
    // Calculate total price
    const tripDate = new Date(trip.date);
    const today = new Date();
    const daysAhead = Math.ceil((tripDate - today) / (1000 * 60 * 60 * 24));
    const pricePerSeat = daysAhead > 7 ? trip.price * 0.9 : trip.price;
    const totalPrice = pricePerSeat * selectedSeats.length;
    
    navigate('/member/checkout', { 
      state: { 
        tripId: trip.id, 
        selectedSeats, 
        totalPrice: totalPrice.toFixed(2),
        hasDiscount: daysAhead > 7
      } 
    });
  };

  if (loading) {
    return (
      <Layout user={user} onLogout={onLogout} isDark={true}>
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-8">
          <div className="text-white/60">Yükleniyor...</div>
        </div>
      </Layout>
    );
  }

  if (!trip || !bus) {
    return (
      <Layout user={user} onLogout={onLogout} isDark={true}>
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-8">
          <div className="text-white/60">Sefer bulunamadı</div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-8">
        <button 
          onClick={() => navigate(-1)} 
          className="flex items-center gap-2 text-white/60 hover:text-white mb-6"
          data-testid="back-btn"
        >
          <ArrowLeft className="w-5 h-5" />
          Geri Dön
        </button>

        <h1 className="text-4xl font-bold text-white mb-8" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
          Koltuk Seçimi
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Seat Map */}
          <div className="lg:col-span-2">
            <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8" data-testid="seat-map">
              <div className="text-center mb-6">
                <p className="text-white/60 text-sm mb-4">Sürücü</p>
                <div className="h-1 bg-white/10 rounded mb-6"></div>
              </div>
              
              <div className="space-y-3 max-w-md mx-auto">
                {bus.seat_layout.map((row, rowIndex) => (
                  <div key={rowIndex} className="flex justify-center gap-2">
                    {row.map((seat, seatIndex) => {
                      if (seat === 0) {
                        return <div key={seatIndex} className="w-12 h-12"></div>;
                      }
                      
                      const isAvailable = trip.available_seats.includes(seat);
                      const isSelected = selectedSeats.includes(seat);
                      
                      return (
                        <button
                          key={seatIndex}
                          onClick={() => toggleSeat(seat)}
                          disabled={!isAvailable}
                          className={`w-12 h-12 rounded-lg font-bold text-sm transition-all ${
                            isSelected
                              ? 'bg-rose-600 text-white'
                              : isAvailable
                              ? 'bg-green-500/20 text-green-500 hover:bg-green-500/30'
                              : 'bg-white/5 text-white/20 cursor-not-allowed'
                          }`}
                          data-testid={`seat-${seat}`}
                        >
                          {seat}
                        </button>
                      );
                    })}
                  </div>
                ))}
              </div>

              <div className="flex justify-center gap-6 mt-8 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-green-500/20"></div>
                  <span className="text-white/60">Müsait</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-rose-600"></div>
                  <span className="text-white/60">Seçili</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-white/5"></div>
                  <span className="text-white/60">Dolu</span>
                </div>
              </div>
            </div>
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-6 sticky top-24" data-testid="summary">
              <h2 className="text-xl font-bold text-white mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>Sefer Detayları</h2>
              
              <div className="space-y-3 text-sm mb-6">
                <div>
                  <p className="text-white/40">Güzergah</p>
                  <p className="text-white font-semibold">{trip.from_city} → {trip.to_city}</p>
                </div>
                <div>
                  <p className="text-white/40">Tarih & Saat</p>
                  <p className="text-white font-semibold">{trip.date} - {trip.time}</p>
                </div>
                <div>
                  <p className="text-white/40">Koltuk Fiyatı</p>
                  <p className="text-white font-semibold">{trip.price} TL</p>
                </div>
              </div>

              <div className="border-t border-white/10 pt-4 mb-6">
                <p className="text-white/40 mb-2">Seçili Koltuklar ({selectedSeats.length})</p>
                {selectedSeats.length > 0 ? (
                  <p className="text-white font-semibold">{selectedSeats.sort((a, b) => a - b).join(', ')}</p>
                ) : (
                  <p className="text-white/40 text-sm">Henüz koltuk seçilmedi</p>
                )}
              </div>

              <button 
                onClick={handleContinue}
                disabled={selectedSeats.length === 0}
                className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
                data-testid="continue-btn"
              >
                Devam Et
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default MemberTripDetail;
