import { useState, useEffect } from "react";
import Layout from "../../components/Layout";
import CompanySidebar from "../../components/CompanySidebar";
import axios from "axios";
import { Plus } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const CompanyBuses = ({ user, onLogout }) => {
  const [buses, setBuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newBus, setNewBus] = useState({ 
    name: '', 
    total_seats: 40,
    rows: 10,
    seatsPerRow: 4
  });

  useEffect(() => {
    fetchBuses();
  }, []);

  const fetchBuses = async () => {
    if (!user.company_id) return;
    try {
      const response = await axios.get(`${API}/company/${user.company_id}/buses`);
      setBuses(response.data);
    } catch (error) {
      console.error("Otobüsler yüklenemedi:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddBus = async (e) => {
    e.preventDefault();
    
    // Generate seat layout
    const layout = [];
    let seatNumber = 1;
    for (let i = 0; i < parseInt(newBus.rows); i++) {
      const row = [];
      for (let j = 0; j < parseInt(newBus.seatsPerRow); j++) {
        if (j === 2) {
          row.push(0); // Aisle
        } else {
          row.push(seatNumber++);
        }
      }
      layout.push(row);
    }

    try {
      await axios.post(`${API}/company/buses`, {
        company_id: user.company_id,
        name: newBus.name,
        total_seats: parseInt(newBus.total_seats),
        seat_layout: layout
      });
      alert('Otobüs başarıyla eklendi');
      setShowAddModal(false);
      setNewBus({ name: '', total_seats: 40, rows: 10, seatsPerRow: 4 });
      fetchBuses();
    } catch (error) {
      alert(error.response?.data?.detail || 'Otobüs eklenemedi');
    }
  };

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="flex">
        <CompanySidebar active="buses" />
        <div className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-4xl font-bold text-white" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
                Otobüs Yönetimi
              </h1>
              <button 
                onClick={() => setShowAddModal(true)} 
                className="btn-primary flex items-center gap-2"
                data-testid="add-bus-btn"
              >
                <Plus className="w-5 h-5" />
                Otobüs Ekle
              </button>
            </div>

            {loading ? (
              <div className="text-white/60">Yükleniyor...</div>
            ) : buses.length === 0 ? (
              <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 text-center text-white/60">
                Henüz otobüs eklenmedi. Yeni otobüs eklemek için yukarıdaki butonu kullanın.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {buses.map((bus) => (
                  <div key={bus.id} className="card-dark" data-testid={`bus-${bus.id}`}>
                    <h3 className="text-xl font-bold text-white mb-4">{bus.name}</h3>
                    <p className="text-white/60 mb-2">Toplam Koltuk: {bus.total_seats}</p>
                    <p className="text-white/60">Düzen: {bus.seat_layout.length} sıra</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add Bus Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50" data-testid="add-modal">
          <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 w-full max-w-md">
            <h2 className="text-2xl font-bold text-white mb-6" style={{ fontFamily: 'Outfit, sans-serif' }}>Yeni Otobüs Ekle</h2>
            <form onSubmit={handleAddBus} className="space-y-4">
              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Otobüs Adı</label>
                <input
                  type="text"
                  className="input-dark w-full"
                  value={newBus.name}
                  onChange={(e) => setNewBus({ ...newBus, name: e.target.value })}
                  placeholder="Örn: Travego 15"
                  data-testid="bus-name-input"
                  required
                />
              </div>
              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Toplam Koltuk Sayısı</label>
                <input
                  type="number"
                  className="input-dark w-full"
                  value={newBus.total_seats}
                  onChange={(e) => setNewBus({ ...newBus, total_seats: e.target.value })}
                  data-testid="total-seats-input"
                  required
                />
              </div>
              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Sıra Sayısı</label>
                <input
                  type="number"
                  className="input-dark w-full"
                  value={newBus.rows}
                  onChange={(e) => setNewBus({ ...newBus, rows: e.target.value })}
                  data-testid="rows-input"
                  required
                />
              </div>
              <div className="flex gap-4">
                <button type="submit" className="btn-primary flex-1" data-testid="submit-bus-btn">Ekle</button>
                <button 
                  type="button" 
                  onClick={() => setShowAddModal(false)} 
                  className="btn-secondary flex-1"
                  data-testid="cancel-bus-btn"
                >
                  İptal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default CompanyBuses;
