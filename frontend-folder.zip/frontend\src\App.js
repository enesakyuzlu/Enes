import { useState, useEffect } from "react";
import "./App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminCompanies from "./pages/admin/AdminCompanies";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminReservations from "./pages/admin/AdminReservations";
import CompanyDashboard from "./pages/company/CompanyDashboard";
import CompanyTrips from "./pages/company/CompanyTrips";
import CompanyBuses from "./pages/company/CompanyBuses";
import CompanyReservations from "./pages/company/CompanyReservations";
import MemberSearch from "./pages/member/MemberSearch";
import MemberTripDetail from "./pages/member/MemberTripDetail";
import MemberCheckout from "./pages/member/MemberCheckout";
import MemberReservations from "./pages/member/MemberReservations";
import MemberProfile from "./pages/member/MemberProfile";

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const handleLogin = (userData) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage user={user} onLogout={handleLogout} />} />
          <Route path="/login" element={<LoginPage onLogin={handleLogin} />} />
          <Route path="/register" element={<RegisterPage />} />
          
          {/* Admin Routes */}
          <Route path="/admin/dashboard" element={user?.role === 'admin' ? <AdminDashboard user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/admin/companies" element={user?.role === 'admin' ? <AdminCompanies user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/admin/users" element={user?.role === 'admin' ? <AdminUsers user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/admin/reservations" element={user?.role === 'admin' ? <AdminReservations user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          
          {/* Company Routes */}
          <Route path="/company/dashboard" element={user?.role === 'company' ? <CompanyDashboard user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/company/trips" element={user?.role === 'company' ? <CompanyTrips user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/company/buses" element={user?.role === 'company' ? <CompanyBuses user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/company/reservations" element={user?.role === 'company' ? <CompanyReservations user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          
          {/* Member Routes */}
          <Route path="/member/search" element={user?.role === 'member' ? <MemberSearch user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/member/trip/:tripId" element={user?.role === 'member' ? <MemberTripDetail user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/member/checkout" element={user?.role === 'member' ? <MemberCheckout user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/member/reservations" element={user?.role === 'member' ? <MemberReservations user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/member/profile" element={user?.role === 'member' ? <MemberProfile user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
