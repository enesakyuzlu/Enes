import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Layout from "../../components/Layout";
import axios from "axios";
import { CreditCard, Tag, AlertCircle } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const MemberCheckout = ({ user, onLogout }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { tripId, selectedSeats, totalPrice, hasDiscount } = location.state || {};
  
  const [cardNumber, setCardNumber] = useState("1135124954");
  const [cardHolder, setCardHolder] = useState("yunus emre topal");
  const [loading, setLoading] = useState(false);

  if (!tripId || !selectedSeats) {
    return (
      <Layout user={user} onLogout={onLogout} isDark={false}>
        <div className="max-w-2xl mx-auto px-6 py-12">
          <div className="text-slate-900">Hatalı sayfa erişimi</div>
        </div>
      </Layout>
    );
  }

  const handlePayment = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.post(`${API}/reservations?user_id=${user.id}`, {
        trip_id: tripId,
        seat_numbers: selectedSeats,
        card_number: cardNumber,
        card_holder: cardHolder
      });

      alert('Ödeme başarılı! Biletiniz hazırlandı.');
      navigate('/member/reservations');
    } catch (error) {
      alert(error.response?.data?.detail || 'Ödeme başarısız');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout user={user} onLogout={onLogout} isDark={false}>
      {/* Pink background wrapper */}
      <div className="bg-pink-50 min-h-[80vh] py-12">
        <div className="max-w-2xl mx-auto px-6">
          {/* White payment card */}
          <div className="bg-white shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-pink-100/50 rounded-2xl p-8" data-testid="checkout-form">
            <h1 className="text-3xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
              Ödeme
            </h1>

            {/* Discount Badge */}
            {hasDiscount && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6 flex items-start gap-3" data-testid="discount-badge">
                <Tag className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <p className="font-semibold text-green-900">%10 İndirim Uygulandı!</p>
                  <p className="text-sm text-green-700">7 günden fazla ileri tarihli bilet rezervasyonu yaptınız.</p>
                </div>
              </div>
            )}

            {/* Summary */}
            <div className="bg-slate-50 rounded-xl p-6 mb-8">
              <h2 className="font-bold text-slate-900 mb-4">Rezervasyon Özeti</h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">Seçili Koltuklar:</span>
                  <span className="font-semibold text-slate-900">{selectedSeats.join(', ')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Koltuk Sayısı:</span>
                  <span className="font-semibold text-slate-900">{selectedSeats.length}</span>
                </div>
                <div className="border-t border-slate-200 pt-2 mt-2">
                  <div className="flex justify-between text-lg">
                    <span className="font-bold text-slate-900">Toplam:</span>
                    <span className="font-bold text-rose-600">{totalPrice} TL</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Payment Info Alert */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 flex items-start gap-3" data-testid="payment-info">
              <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
              <div className="text-sm text-blue-900">
                <p className="font-semibold mb-1">Test Ödeme Sistemi</p>
                <p>Kart Numarası: <code className="bg-blue-100 px-2 py-0.5 rounded">1135124954</code></p>
                <p>Kart Sahibi: <code className="bg-blue-100 px-2 py-0.5 rounded">yunus emre topal</code></p>
              </div>
            </div>

            {/* Payment Form */}
            <form onSubmit={handlePayment} className="space-y-6">
              <div>
                <label className="block text-slate-700 font-semibold mb-2">
                  <CreditCard className="w-4 h-4 inline mr-2" />
                  Kart Numarası
                </label>
                <input
                  type="text"
                  className="input-light w-full"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  placeholder="Kart numarası"
                  data-testid="card-number-input"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-2">Kart Sahibi</label>
                <input
                  type="text"
                  className="input-light w-full"
                  value={cardHolder}
                  onChange={(e) => setCardHolder(e.target.value)}
                  placeholder="Kart sahibinin adı"
                  data-testid="card-holder-input"
                  required
                />
              </div>

              <button 
                type="submit" 
                className="bg-rose-600 hover:bg-rose-700 text-white font-semibold py-4 px-6 rounded-xl w-full transition-all active:scale-[0.98]"
                disabled={loading}
                data-testid="pay-btn"
              >
                {loading ? 'Ödeme yapılıyor...' : `${totalPrice} TL Öde`}
              </button>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default MemberCheckout;
