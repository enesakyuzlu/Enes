import { useState, useEffect } from "react";
import Layout from "../../components/Layout";
import AdminSidebar from "../../components/AdminSidebar";
import axios from "axios";
import { Plus, Trash2, User } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const AdminUsers = ({ user, onLogout }) => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newUser, setNewUser] = useState({ 
    tc_kimlik: '', 
    name: '', 
    email: '', 
    age: '', 
    password: '', 
    role: 'member',
    company_id: ''
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.get(`${API}/admin/users`);
      setUsers(response.data);
    } catch (error) {
      console.error("Kullanıcılar yüklenemedi:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddUser = async (e) => {
    e.preventDefault();
    if (newUser.tc_kimlik.length !== 11) {
      alert('TC Kimlik numarası 11 haneli olmalıdır');
      return;
    }
    try {
      await axios.post(`${API}/admin/users`, {
        ...newUser,
        age: parseInt(newUser.age)
      });
      alert('Kullanıcı başarıyla eklendi');
      setShowAddModal(false);
      setNewUser({ tc_kimlik: '', name: '', email: '', age: '', password: '', role: 'member', company_id: '' });
      fetchUsers();
    } catch (error) {
      alert(error.response?.data?.detail || 'Kullanıcı eklenemedi');
    }
  };

  const handleDeleteUser = async (id) => {
    if (!window.confirm('Bu kullanıcıyı silmek istediğinize emin misiniz?')) return;
    try {
      await axios.delete(`${API}/admin/users/${id}`);
      alert('Kullanıcı silindi');
      fetchUsers();
    } catch (error) {
      alert(error.response?.data?.detail || 'Kullanıcı silinemedi');
    }
  };

  const getRoleBadge = (role) => {
    const colors = {
      admin: 'bg-red-500/10 text-red-500',
      company: 'bg-blue-500/10 text-blue-500',
      member: 'bg-green-500/10 text-green-500'
    };
    const labels = {
      admin: 'Admin',
      company: 'Firma',
      member: 'Üye'
    };
    return (
      <span className={`px-2 py-1 rounded text-xs font-bold ${colors[role]}`}>
        {labels[role]}
      </span>
    );
  };

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="flex">
        <AdminSidebar active="users" />
        <div className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-4xl font-bold text-white" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
                Kullanıcı Yönetimi
              </h1>
              <button 
                onClick={() => setShowAddModal(true)} 
                className="btn-primary flex items-center gap-2"
                data-testid="add-user-btn"
              >
                <Plus className="w-5 h-5" />
                Kullanıcı Ekle
              </button>
            </div>

            {loading ? (
              <div className="text-white/60">Yükleniyor...</div>
            ) : (
              <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl overflow-hidden">
                <table className="w-full" data-testid="users-table">
                  <thead className="bg-white/5">
                    <tr>
                      <th className="text-left text-white/60 font-semibold p-4">Ad Soyad</th>
                      <th className="text-left text-white/60 font-semibold p-4">TC Kimlik</th>
                      <th className="text-left text-white/60 font-semibold p-4">E-posta</th>
                      <th className="text-left text-white/60 font-semibold p-4">Yaş</th>
                      <th className="text-left text-white/60 font-semibold p-4">Rol</th>
                      <th className="text-left text-white/60 font-semibold p-4">Açıklamalar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u) => (
                      <tr key={u.id} className="border-t border-white/5" data-testid={`user-${u.id}`}>
                        <td className="text-white p-4">{u.name}</td>
                        <td className="text-white/60 p-4 font-mono text-sm">{u.tc_kimlik}</td>
                        <td className="text-white/60 p-4">{u.email || '-'}</td>
                        <td className="text-white/60 p-4">{u.age || '-'}</td>
                        <td className="p-4">{getRoleBadge(u.role)}</td>
                        <td className="p-4">
                          <button 
                            onClick={() => handleDeleteUser(u.id)} 
                            className="text-rose-500 hover:text-rose-400"
                            data-testid={`delete-user-${u.id}`}
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add User Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 overflow-y-auto" data-testid="add-modal">
          <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 w-full max-w-md my-8">
            <h2 className="text-2xl font-bold text-white mb-6" style={{ fontFamily: 'Outfit, sans-serif' }}>Yeni Kullanıcı Ekle</h2>
            <form onSubmit={handleAddUser} className="space-y-4">
              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">TC Kimlik No</label>
                <input
                  type="text"
                  className="input-dark w-full"
                  value={newUser.tc_kimlik}
                  onChange={(e) => setNewUser({ ...newUser, tc_kimlik: e.target.value.replace(/\D/g, '').slice(0, 11) })}
                  placeholder="11 haneli TC kimlik"
                  maxLength={11}
                  data-testid="tc-kimlik-input"
                  required
                />
                <p className="text-xs text-white/40 mt-1">{newUser.tc_kimlik.length}/11</p>
              </div>
              
              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Ad Soyad</label>
                <input
                  type="text"
                  className="input-dark w-full"
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  data-testid="name-input"
                  required
                />
              </div>

              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">E-posta</label>
                <input
                  type="email"
                  className="input-dark w-full"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  data-testid="email-input"
                />
              </div>

              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Yaş</label>
                <input
                  type="number"
                  className="input-dark w-full"
                  value={newUser.age}
                  onChange={(e) => setNewUser({ ...newUser, age: e.target.value })}
                  data-testid="age-input"
                />
              </div>

              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Rol</label>
                <select
                  className="input-dark w-full"
                  value={newUser.role}
                  onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                  data-testid="role-select"
                >
                  <option value="member">Üye</option>
                  <option value="company">Firma</option>
                  <option value="admin">Admin</option>
                </select>
              </div>

              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Şifre</label>
                <input
                  type="password"
                  className="input-dark w-full"
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  data-testid="password-input"
                  required
                />
              </div>

              <div className="flex gap-4">
                <button type="submit" className="btn-primary flex-1" data-testid="submit-user-btn">Ekle</button>
                <button 
                  type="button" 
                  onClick={() => setShowAddModal(false)} 
                  className="btn-secondary flex-1"
                  data-testid="cancel-user-btn"
                >
                  İptal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default AdminUsers;
