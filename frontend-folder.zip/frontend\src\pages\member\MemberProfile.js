import { useState } from "react";
import Layout from "../../components/Layout";
import axios from "axios";
import { User, Save } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const MemberProfile = ({ user, onLogout }) => {
  const [name, setName] = useState(user.name || '');
  const [age, setAge] = useState(user.age || '');
  const [email, setEmail] = useState(user.email || '');
  const [loading, setLoading] = useState(false);

  const handleSave = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.put(`${API}/member/${user.id}/profile`, null, {
        params: {
          name: name || undefined,
          age: age ? parseInt(age) : undefined,
          email: email || undefined
        }
      });
      
      // Update local storage
      const updatedUser = { ...user, name, age: parseInt(age), email };
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      alert('Profil güncellendi');
    } catch (error) {
      alert(error.response?.data?.detail || 'Profil güncellenemedi');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="max-w-3xl mx-auto px-6 md:px-12 py-8">
        <h1 className="text-4xl font-bold text-white mb-8" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
          Profilim
        </h1>

        <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8" data-testid="profile-form">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-16 h-16 rounded-full bg-rose-500/10 flex items-center justify-center">
              <User className="w-8 h-8 text-rose-500" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">{user.name}</h2>
              <p className="text-white/60">TC: {user.tc_kimlik}</p>
            </div>
          </div>

          <form onSubmit={handleSave} className="space-y-6">
            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Ad Soyad</label>
              <input
                type="text"
                className="input-dark w-full"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Adınızı girin"
                data-testid="name-input"
              />
            </div>

            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Yaş</label>
              <input
                type="number"
                className="input-dark w-full"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="Yaşınızı girin"
                min="1"
                max="120"
                data-testid="age-input"
              />
            </div>

            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">E-posta</label>
              <input
                type="email"
                className="input-dark w-full"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="E-posta adresiniz"
                data-testid="email-input"
              />
            </div>

            <button 
              type="submit" 
              className="btn-primary w-full flex items-center justify-center gap-2"
              disabled={loading}
              data-testid="save-btn"
            >
              <Save className="w-5 h-5" />
              {loading ? 'Kaydediliyor...' : 'Değişiklikleri Kaydet'}
            </button>
          </form>
        </div>
      </div>
    </Layout>
  );
};

export default MemberProfile;
