import { Link } from "react-router-dom";
import { Bus, LogOut, User } from "lucide-react";

const Layout = ({ children, user, onLogout, isDark = true }) => {
  return (
    <div className={`min-h-screen ${isDark ? 'bg-[#0A0A0A]' : 'bg-pink-50'}`}>
      {/* Header */}
      <header className="glass-header">
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2" data-testid="logo-link">
            <Bus className="w-8 h-8 text-rose-600" />
            <span className="text-2xl font-bold text-white" style={{ fontFamily: 'Outfit, sans-serif' }}>En Ucuza Bilet</span>
          </Link>
          
          <div className="flex items-center gap-4">
            {user ? (
              <>
                <div className="flex items-center gap-2 text-white/80">
                  <User className="w-5 h-5" />
                  <span data-testid="user-name">{user.name}</span>
                </div>
                <button onClick={onLogout} className="btn-secondary flex items-center gap-2" data-testid="logout-btn">
                  <LogOut className="w-4 h-4" />
                  Çıkış
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-secondary" data-testid="login-btn">Giriş Yap</Link>
                <Link to="/register" className="btn-primary" data-testid="register-btn">Kayıt Ol</Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main>{children}</main>

      {/* Footer */}
      <footer className="bg-[#1F2937] text-white/70 py-8 mt-20">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="flex justify-between items-center">
            <p>© 2026 En Ucuza Bilet. Tüm hakları saklıdır.</p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-white transition-colors" data-testid="customer-service-link">Müşteri Hizmetleri</a>
              <a href="#" className="hover:text-white transition-colors">İletişim</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
