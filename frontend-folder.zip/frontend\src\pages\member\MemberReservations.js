import { useState, useEffect } from "react";
import Layout from "../../components/Layout";
import axios from "axios";
import { Ticket, Trash2 } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const MemberReservations = ({ user, onLogout }) => {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchReservations();
  }, []);

  const fetchReservations = async () => {
    try {
      const response = await axios.get(`${API}/member/${user.id}/reservations`);
      setReservations(response.data);
    } catch (error) {
      console.error("Rezervasyonlar yüklenemedi:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelReservation = async (id) => {
    if (!window.confirm('Rezervasyonunuzu iptal etmek istediğinize emin misiniz?')) return;
    
    try {
      await axios.delete(`${API}/reservations/${id}`);
      alert('Rezervasyon iptal edildi');
      fetchReservations();
    } catch (error) {
      alert(error.response?.data?.detail || 'Rezervasyon iptal edilemedi');
    }
  };

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-8">
        <h1 className="text-4xl font-bold text-white mb-8" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
          Biletlerim
        </h1>

        {loading ? (
          <div className="text-white/60">Yükleniyor...</div>
        ) : reservations.length === 0 ? (
          <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 text-center">
            <Ticket className="w-16 h-16 text-white/20 mx-auto mb-4" />
            <p className="text-white/60">Henüz biletiniz yok</p>
          </div>
        ) : (
          <div className="space-y-4">
            {reservations.map((reservation) => (
              <div key={reservation.id} className="card-dark" data-testid={`reservation-${reservation.id}`}>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-3">
                      <Ticket className="w-5 h-5 text-rose-500" />
                      <h3 className="text-lg font-bold text-white">Rezervasyon #{reservation.id.slice(0, 8)}</h3>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-white/60 text-sm">
                      <div>
                        <p className="text-white/40">Koltuklar</p>
                        <p className="text-white font-semibold">{reservation.seat_numbers.join(', ')}</p>
                      </div>
                      <div>
                        <p className="text-white/40">Toplam Fiyat</p>
                        <p className="text-rose-500 font-bold text-lg">{reservation.total_price} TL</p>
                      </div>
                      <div>
                        <p className="text-white/40">Durum</p>
                        <span className="px-2 py-1 rounded text-xs font-bold bg-green-500/10 text-green-500">
                          {reservation.status}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button 
                    onClick={() => handleCancelReservation(reservation.id)} 
                    className="text-rose-500 hover:text-rose-400 ml-4"
                    data-testid={`cancel-${reservation.id}`}
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default MemberReservations;
