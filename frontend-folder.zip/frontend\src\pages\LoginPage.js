import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import Layout from "../components/Layout";
import axios from "axios";
import { LogIn } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const LoginPage = ({ onLogin }) => {
  const navigate = useNavigate();
  const [role, setRole] = useState("member");
  const [tcKimlik, setTcKimlik] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (tcKimlik.length !== 11) {
      setError("TC Kimlik numarası 11 haneli olmalıdır");
      setLoading(false);
      return;
    }

    try {
      const endpoint = role === 'admin' ? '/admin/login' : role === 'company' ? '/company/login' : '/member/login';
      const response = await axios.post(`${API}${endpoint}`, {
        tc_kimlik: tcKimlik,
        password: password
      });

      onLogin(response.data.user);
      
      if (role === 'admin') {
        navigate('/admin/dashboard');
      } else if (role === 'company') {
        navigate('/company/dashboard');
      } else {
        navigate('/member/search');
      }
    } catch (err) {
      setError(err.response?.data?.detail || "Giriş başarısız");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout isDark={true}>
      <div className="min-h-[80vh] flex items-center justify-center px-6">
        <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 w-full max-w-md" data-testid="login-form">
          <div className="text-center mb-8">
            <LogIn className="w-12 h-12 text-rose-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-white" style={{ fontFamily: 'Outfit, sans-serif' }}>Giriş Yap</h2>
            <p className="text-white/60 mt-2">Hesabınıza erişin</p>
          </div>

          {error && (
            <div className="bg-rose-500/10 border border-rose-500/50 text-rose-400 px-4 py-3 rounded-lg mb-4" data-testid="error-message">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Hesap Tipi</label>
              <div className="grid grid-cols-3 gap-2">
                {['member', 'company', 'admin'].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRole(r)}
                    className={`py-2 px-4 rounded-lg font-medium transition-all ${
                      role === r 
                        ? 'bg-rose-600 text-white' 
                        : 'bg-white/5 text-white/60 hover:bg-white/10'
                    }`}
                    data-testid={`role-${r}-btn`}
                  >
                    {r === 'member' ? 'Üye' : r === 'company' ? 'Firma' : 'Admin'}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">TC Kimlik No</label>
              <input
                type="text"
                className="input-dark w-full"
                value={tcKimlik}
                onChange={(e) => setTcKimlik(e.target.value.replace(/\D/g, '').slice(0, 11))}
                placeholder="11 haneli TC kimlik numarası"
                maxLength={11}
                data-testid="tc-kimlik-input"
                required
              />
              <p className="text-xs text-white/40 mt-1">{tcKimlik.length}/11</p>
            </div>

            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Şifre</label>
              <input
                type="password"
                className="input-dark w-full"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Şifrenizi girin"
                data-testid="password-input"
                required
              />
            </div>

            <button 
              type="submit" 
              className="btn-primary w-full" 
              disabled={loading}
              data-testid="submit-btn"
            >
              {loading ? 'Giriş yapılıyor...' : 'Giriş Yap'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-white/60">
              Hesabınız yok mu?{' '}
              <Link to="/register" className="text-rose-500 hover:text-rose-400 font-medium" data-testid="register-link">
                Kayıt Ol
              </Link>
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default LoginPage;
