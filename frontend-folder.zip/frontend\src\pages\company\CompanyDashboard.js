import Layout from "../../components/Layout";
import CompanySidebar from "../../components/CompanySidebar";

const CompanyDashboard = ({ user, onLogout }) => {
  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="flex">
        <CompanySidebar active="dashboard" />
        <div className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-4xl font-bold text-white mb-8" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
              Firma Dashboard
            </h1>

            <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-bold text-white mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>Hoş Geldiniz</h2>
              <p className="text-white/60">
                Firma panelinize hoş geldiniz. Sol menüden otobüslerinizi, seferlerinizi ve rezervasyonlarınızı yönetebilirsiniz.
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default CompanyDashboard;
