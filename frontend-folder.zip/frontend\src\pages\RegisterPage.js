import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import Layout from "../components/Layout";
import axios from "axios";
import { UserPlus } from "lucide-react";

// Aynı domain altında deploy edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const RegisterPage = () => {
  const navigate = useNavigate();
  const [tcKimlik, setTcKimlik] = useState("");
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (tcKimlik.length !== 11) {
      setError("TC Kimlik numarası 11 haneli olmalıdır");
      setLoading(false);
      return;
    }

    try {
      await axios.post(`${API}/member/register`, {
        tc_kimlik: tcKimlik,
        name,
        age: parseInt(age),
        email,
        password,
        role: "member"
      });

      alert("Kayıt başarılı! Giriş yapabilirsiniz.");
      navigate('/login');
    } catch (err) {
      setError(err.response?.data?.detail || "Kayıt başarısız");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout isDark={true}>
      <div className="min-h-[80vh] flex items-center justify-center px-6 py-12">
        <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 w-full max-w-md" data-testid="register-form">
          <div className="text-center mb-8">
            <UserPlus className="w-12 h-12 text-rose-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-white" style={{ fontFamily: 'Outfit, sans-serif' }}>Kayıt Ol</h2>
            <p className="text-white/60 mt-2">Yeni hesap oluşturun</p>
          </div>

          {error && (
            <div className="bg-rose-500/10 border border-rose-500/50 text-rose-400 px-4 py-3 rounded-lg mb-4" data-testid="error-message">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">TC Kimlik No</label>
              <input
                type="text"
                className="input-dark w-full"
                value={tcKimlik}
                onChange={(e) => setTcKimlik(e.target.value.replace(/\D/g, '').slice(0, 11))}
                placeholder="11 haneli TC kimlik numarası"
                maxLength={11}
                data-testid="tc-kimlik-input"
                required
              />
              <p className="text-xs text-white/40 mt-1">{tcKimlik.length}/11</p>
            </div>

            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Ad Soyad</label>
              <input
                type="text"
                className="input-dark w-full"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Adınızı girin"
                data-testid="name-input"
                required
              />
            </div>

            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Yaş</label>
              <input
                type="number"
                className="input-dark w-full"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="Yaşınızı girin"
                min="1"
                max="120"
                data-testid="age-input"
                required
              />
            </div>

            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">E-posta</label>
              <input
                type="email"
                className="input-dark w-full"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ornek@email.com"
                data-testid="email-input"
                required
              />
            </div>

            <div>
              <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Şifre</label>
              <input
                type="password"
                className="input-dark w-full"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Şifre oluşturun"
                data-testid="password-input"
                required
              />
            </div>

            <button 
              type="submit" 
              className="btn-primary w-full" 
              disabled={loading}
              data-testid="submit-btn"
            >
              {loading ? 'Kayıt yapılıyor...' : 'Kayıt Ol'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-white/60">
              Zaten hesabınız var mı?{' '}
              <Link to="/login" className="text-rose-500 hover:text-rose-400 font-medium" data-testid="login-link">
                Giriş Yap
              </Link>
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default RegisterPage;
