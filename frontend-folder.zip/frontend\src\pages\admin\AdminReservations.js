import { useState, useEffect } from "react";
import Layout from "../../components/Layout";
import AdminSidebar from "../../components/AdminSidebar";
import axios from "axios";
import { Ticket } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const AdminReservations = ({ user, onLogout }) => {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchReservations();
  }, []);

  const fetchReservations = async () => {
    try {
      const response = await axios.get(`${API}/admin/reservations`);
      setReservations(response.data);
    } catch (error) {
      console.error("Rezervasyonlar yüklenemedi:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="flex">
        <AdminSidebar active="reservations" />
        <div className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-4xl font-bold text-white" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
                Tüm Rezervasyonlar
              </h1>
            </div>

            {loading ? (
              <div className="text-white/60">Yükleniyor...</div>
            ) : reservations.length === 0 ? (
              <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 text-center text-white/60">
                Henüz rezervasyon yok
              </div>
            ) : (
              <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl overflow-hidden">
                <table className="w-full" data-testid="reservations-table">
                  <thead className="bg-white/5">
                    <tr>
                      <th className="text-left text-white/60 font-semibold p-4">Rezervasyon ID</th>
                      <th className="text-left text-white/60 font-semibold p-4">Kullanıcı ID</th>
                      <th className="text-left text-white/60 font-semibold p-4">Sefer ID</th>
                      <th className="text-left text-white/60 font-semibold p-4">Koltuklar</th>
                      <th className="text-left text-white/60 font-semibold p-4">Toplam Fiyat</th>
                      <th className="text-left text-white/60 font-semibold p-4">Durum</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reservations.map((r) => (
                      <tr key={r.id} className="border-t border-white/5" data-testid={`reservation-${r.id}`}>
                        <td className="text-white/60 p-4 font-mono text-xs">{r.id.slice(0, 8)}...</td>
                        <td className="text-white/60 p-4 font-mono text-xs">{r.user_id.slice(0, 8)}...</td>
                        <td className="text-white/60 p-4 font-mono text-xs">{r.trip_id.slice(0, 8)}...</td>
                        <td className="text-white p-4">{r.seat_numbers.join(', ')}</td>
                        <td className="text-white p-4 font-bold">{r.total_price} TL</td>
                        <td className="p-4">
                          <span className="px-2 py-1 rounded text-xs font-bold bg-green-500/10 text-green-500">
                            {r.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default AdminReservations;
