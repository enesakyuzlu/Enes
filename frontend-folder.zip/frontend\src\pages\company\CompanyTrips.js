import { useState, useEffect } from "react";
import Layout from "../../components/Layout";
import CompanySidebar from "../../components/CompanySidebar";
import axios from "axios";
import { Plus, Trash2, Edit } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const CompanyTrips = ({ user, onLogout }) => {
  const [trips, setTrips] = useState([]);
  const [buses, setBuses] = useState([]);
  const [cities, setCities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTrip, setNewTrip] = useState({ 
    bus_id: '',
    from_city: '', 
    to_city: '', 
    date: '',
    time: '',
    price: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    if (!user.company_id) return;
    try {
      const [tripsRes, busesRes, citiesRes] = await Promise.all([
        axios.get(`${API}/company/${user.company_id}/trips`),
        axios.get(`${API}/company/${user.company_id}/buses`),
        axios.get(`${API}/cities`)
      ]);
      setTrips(tripsRes.data);
      setBuses(busesRes.data);
      setCities(citiesRes.data.cities);
    } catch (error) {
      console.error("Veri yüklenemedi:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddTrip = async (e) => {
    e.preventDefault();
    
    const selectedBus = buses.find(b => b.id === newTrip.bus_id);
    if (!selectedBus) {
      alert('Lütfen bir otobüs seçin');
      return;
    }

    // Generate available seats from bus layout
    const availableSeats = [];
    selectedBus.seat_layout.forEach(row => {
      row.forEach(seat => {
        if (seat !== 0) availableSeats.push(seat);
      });
    });

    try {
      await axios.post(`${API}/company/trips`, {
        company_id: user.company_id,
        bus_id: newTrip.bus_id,
        from_city: newTrip.from_city,
        to_city: newTrip.to_city,
        date: newTrip.date,
        time: newTrip.time,
        price: parseFloat(newTrip.price),
        available_seats: availableSeats
      });
      alert('Sefer başarıyla eklendi');
      setShowAddModal(false);
      setNewTrip({ bus_id: '', from_city: '', to_city: '', date: '', time: '', price: '' });
      fetchData();
    } catch (error) {
      alert(error.response?.data?.detail || 'Sefer eklenemedi');
    }
  };

  const handleDeleteTrip = async (id) => {
    if (!window.confirm('Bu seferi silmek istediğinize emin misiniz?')) return;
    try {
      await axios.delete(`${API}/company/trips/${id}`);
      alert('Sefer silindi');
      fetchData();
    } catch (error) {
      alert(error.response?.data?.detail || 'Sefer silinemedi');
    }
  };

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="flex">
        <CompanySidebar active="trips" />
        <div className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-4xl font-bold text-white" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
                Sefer Yönetimi
              </h1>
              <button 
                onClick={() => setShowAddModal(true)} 
                className="btn-primary flex items-center gap-2"
                data-testid="add-trip-btn"
                disabled={buses.length === 0}
              >
                <Plus className="w-5 h-5" />
                Sefer Ekle
              </button>
            </div>

            {buses.length === 0 && (
              <div className="bg-yellow-500/10 border border-yellow-500/50 text-yellow-400 px-4 py-3 rounded-lg mb-4">
                Sefer eklemeden önce en az bir otobüs eklemelisiniz.
              </div>
            )}

            {loading ? (
              <div className="text-white/60">Yükleniyor...</div>
            ) : trips.length === 0 ? (
              <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 text-center text-white/60">
                Henüz sefer eklenmedi.
              </div>
            ) : (
              <div className="space-y-4">
                {trips.map((trip) => (
                  <div key={trip.id} className="card-dark flex justify-between items-center" data-testid={`trip-${trip.id}`}>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-white mb-2">
                        {trip.from_city} → {trip.to_city}
                      </h3>
                      <div className="flex gap-4 text-white/60 text-sm">
                        <span>{trip.date}</span>
                        <span>{trip.time}</span>
                        <span className="font-bold text-rose-500">{trip.price} TL</span>
                        <span>Boş Koltuk: {trip.available_seats.length}</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => handleDeleteTrip(trip.id)} 
                      className="text-rose-500 hover:text-rose-400"
                      data-testid={`delete-trip-${trip.id}`}
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add Trip Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 overflow-y-auto" data-testid="add-modal">
          <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 w-full max-w-md my-8">
            <h2 className="text-2xl font-bold text-white mb-6" style={{ fontFamily: 'Outfit, sans-serif' }}>Yeni Sefer Ekle</h2>
            <form onSubmit={handleAddTrip} className="space-y-4">
              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Otobüs</label>
                <select
                  className="input-dark w-full"
                  value={newTrip.bus_id}
                  onChange={(e) => setNewTrip({ ...newTrip, bus_id: e.target.value })}
                  data-testid="bus-select"
                  required
                >
                  <option value="">Otobüs seçin</option>
                  {buses.map((bus) => (
                    <option key={bus.id} value={bus.id}>{bus.name} ({bus.total_seats} koltuk)</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Kalkış</label>
                <select
                  className="input-dark w-full"
                  value={newTrip.from_city}
                  onChange={(e) => setNewTrip({ ...newTrip, from_city: e.target.value })}
                  data-testid="from-city-select"
                  required
                >
                  <option value="">Şehir seçin</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Varış</label>
                <select
                  className="input-dark w-full"
                  value={newTrip.to_city}
                  onChange={(e) => setNewTrip({ ...newTrip, to_city: e.target.value })}
                  data-testid="to-city-select"
                  required
                >
                  <option value="">Şehir seçin</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Tarih</label>
                <input
                  type="date"
                  className="input-dark w-full"
                  value={newTrip.date}
                  onChange={(e) => setNewTrip({ ...newTrip, date: e.target.value })}
                  min={new Date().toISOString().split('T')[0]}
                  data-testid="date-input"
                  required
                />
              </div>

              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Saat</label>
                <input
                  type="time"
                  className="input-dark w-full"
                  value={newTrip.time}
                  onChange={(e) => setNewTrip({ ...newTrip, time: e.target.value })}
                  data-testid="time-input"
                  required
                />
              </div>

              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Fiyat (TL)</label>
                <input
                  type="number"
                  step="0.01"
                  className="input-dark w-full"
                  value={newTrip.price}
                  onChange={(e) => setNewTrip({ ...newTrip, price: e.target.value })}
                  data-testid="price-input"
                  required
                />
              </div>

              <div className="flex gap-4">
                <button type="submit" className="btn-primary flex-1" data-testid="submit-trip-btn">Ekle</button>
                <button 
                  type="button" 
                  onClick={() => setShowAddModal(false)} 
                  className="btn-secondary flex-1"
                  data-testid="cancel-trip-btn"
                >
                  İptal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default CompanyTrips;
