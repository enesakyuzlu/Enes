import { useState, useEffect } from "react";
import Layout from "../../components/Layout";
import AdminSidebar from "../../components/AdminSidebar";
import axios from "axios";
import { Users, Building2, Ticket, TrendingUp } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const AdminDashboard = ({ user, onLogout }) => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await axios.get(`${API}/admin/stats`);
        setStats(response.data);
      } catch (error) {
        console.error("Stats yüklenemedi:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  const statCards = [
    { label: 'Toplam Kullanıcılar', value: stats?.total_users || 0, icon: Users, color: 'rose' },
    { label: 'Toplam Firmalar', value: stats?.total_companies || 0, icon: Building2, color: 'blue' },
    { label: 'Toplam Seferler', value: stats?.total_trips || 0, icon: TrendingUp, color: 'green' },
    { label: 'Toplam Rezervasyonlar', value: stats?.total_reservations || 0, icon: Ticket, color: 'purple' },
  ];

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="flex">
        <AdminSidebar active="dashboard" />
        <div className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-4xl font-bold text-white mb-8" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
              Admin Dashboard
            </h1>

            {loading ? (
              <div className="text-white/60">Yükleniyor...</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {statCards.map((card) => {
                  const Icon = card.icon;
                  return (
                    <div key={card.label} className="card-dark" data-testid={`stat-${card.label}`}>
                      <div className="flex items-start justify-between mb-4">
                        <div className={`p-3 rounded-xl bg-${card.color}-500/10`}>
                          <Icon className={`w-6 h-6 text-${card.color}-500`} />
                        </div>
                      </div>
                      <p className="text-3xl font-bold text-white mb-1">{card.value}</p>
                      <p className="text-white/60 text-sm">{card.label}</p>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="mt-8 bg-[#1A1A1A] border border-white/10 rounded-2xl p-6">
              <h2 className="text-2xl font-bold text-white mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>Hoş Geldiniz</h2>
              <p className="text-white/60">
                Admin panelinize hoş geldiniz. Sol menüden firmalar, kullanıcılar ve rezervasyonları yönetebilirsiniz.
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default AdminDashboard;
