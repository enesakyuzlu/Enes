import { useState, useEffect } from "react";
import Layout from "../../components/Layout";
import AdminSidebar from "../../components/AdminSidebar";
import axios from "axios";
import { Plus, Trash2, Building2 } from "lucide-react";

// Aynı domain altında publish edilince API'yi relative çağırır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const AdminCompanies = ({ user, onLogout }) => {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCompany, setNewCompany] = useState({ name: '', logo: '' });

  useEffect(() => {
    fetchCompanies();
  }, []);

  const fetchCompanies = async () => {
    try {
      const response = await axios.get(`${API}/admin/companies`);
      setCompanies(response.data);
    } catch (error) {
      console.error("Firmalar yüklenemedi:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddCompany = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/admin/companies`, newCompany);
      alert('Firma başarıyla eklendi');
      setShowAddModal(false);
      setNewCompany({ name: '', logo: '' });
      fetchCompanies();
    } catch (error) {
      alert(error.response?.data?.detail || 'Firma eklenemedi');
    }
  };

  const handleDeleteCompany = async (id) => {
    if (!window.confirm('Bu firmayı silmek istediğinize emin misiniz?')) return;
    try {
      await axios.delete(`${API}/admin/companies/${id}`);
      alert('Firma silindi');
      fetchCompanies();
    } catch (error) {
      alert(error.response?.data?.detail || 'Firma silinemedi');
    }
  };

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="flex">
        <AdminSidebar active="companies" />
        <div className="flex-1 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-4xl font-bold text-white" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="page-title">
                Firma Yönetimi
              </h1>
              <button 
                onClick={() => setShowAddModal(true)} 
                className="btn-primary flex items-center gap-2"
                data-testid="add-company-btn"
              >
                <Plus className="w-5 h-5" />
                Firma Ekle
              </button>
            </div>

            {loading ? (
              <div className="text-white/60">Yükleniyor...</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {companies.map((company) => (
                  <div key={company.id} className="card-dark" data-testid={`company-${company.id}`}>
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-3 rounded-xl bg-blue-500/10">
                          <Building2 className="w-6 h-6 text-blue-500" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-white">{company.name}</h3>
                          <p className="text-xs text-white/40">{company.status}</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => handleDeleteCompany(company.id)} 
                        className="text-rose-500 hover:text-rose-400"
                        data-testid={`delete-company-${company.id}`}
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add Company Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50" data-testid="add-modal">
          <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-8 w-full max-w-md">
            <h2 className="text-2xl font-bold text-white mb-6" style={{ fontFamily: 'Outfit, sans-serif' }}>Yeni Firma Ekle</h2>
            <form onSubmit={handleAddCompany} className="space-y-4">
              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Firma Adı</label>
                <input
                  type="text"
                  className="input-dark w-full"
                  value={newCompany.name}
                  onChange={(e) => setNewCompany({ ...newCompany, name: e.target.value })}
                  placeholder="Firma adını girin"
                  data-testid="company-name-input"
                  required
                />
              </div>
              <div>
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Logo URL (opsiyonel)</label>
                <input
                  type="text"
                  className="input-dark w-full"
                  value={newCompany.logo}
                  onChange={(e) => setNewCompany({ ...newCompany, logo: e.target.value })}
                  placeholder="Logo URL'i girin"
                  data-testid="company-logo-input"
                />
              </div>
              <div className="flex gap-4">
                <button type="submit" className="btn-primary flex-1" data-testid="submit-company-btn">Ekle</button>
                <button 
                  type="button" 
                  onClick={() => setShowAddModal(false)} 
                  className="btn-secondary flex-1"
                  data-testid="cancel-company-btn"
                >
                  İptal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default AdminCompanies;
