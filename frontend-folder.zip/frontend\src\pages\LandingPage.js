import Layout from "../components/Layout";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Calendar } from "lucide-react";
import axios from "axios";

// Aynı domain altında yayınlanınca API'yi relative çağırmak gerekir.
// Development'ta .env'den gelen REACT_APP_BACKEND_URL kullanılır.
const API =
  process.env.NODE_ENV === "production"
    ? "/api"
    : `${process.env.REACT_APP_BACKEND_URL || ""}/api`;

const LandingPage = ({ user, onLogout }) => {
  const navigate = useNavigate();
  const [cities, setCities] = useState([]);
  const [fromCity, setFromCity] = useState("");
  const [toCity, setToCity] = useState("");
  const [date, setDate] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchCities = async () => {
      try {
        const response = await axios.get(`${API}/cities`);
        setCities(response.data.cities);
      } catch (error) {
        console.error("Şehirler yüklenemedi:", error);
      }
    };
    fetchCities();
  }, []);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!fromCity || !toCity || !date) {
      alert("Lütfen tüm alanları doldurun");
      return;
    }
    
    if (!user) {
      navigate('/login');
      return;
    }
    
    navigate(`/member/search?from=${fromCity}&to=${toCity}&date=${date}`);
  };

  return (
    <Layout user={user} onLogout={onLogout} isDark={true}>
      <div className="relative min-h-[80vh] flex items-center justify-center">
        {/* Hero Background */}
        <div 
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/34612274/pexels-photo-34612274.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        >
          <div className="absolute inset-0 bg-black/70"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-4xl mx-auto px-6 md:px-12 text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 tracking-tighter" style={{ fontFamily: 'Outfit, sans-serif' }} data-testid="hero-title">
            Türkiye'nin En Uygun Biletleri
          </h1>
          <p className="text-lg text-white/80 mb-12 max-w-2xl mx-auto" data-testid="hero-subtitle">
            81 ile, yüzlerce firma ile güvenli ve hızlı bilet satın alın. İleri tarihli biletlerde %10 indirim!
          </p>

          {/* Search Widget */}
          <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl shadow-2xl p-6 md:p-8" data-testid="search-widget">
            <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-1">
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Nereden</label>
                <select 
                  className="input-dark w-full" 
                  value={fromCity} 
                  onChange={(e) => setFromCity(e.target.value)}
                  data-testid="from-city-select"
                >
                  <option value="">Şehir Seçin</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-1">
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Nereye</label>
                <select 
                  className="input-dark w-full" 
                  value={toCity} 
                  onChange={(e) => setToCity(e.target.value)}
                  data-testid="to-city-select"
                >
                  <option value="">Şehir Seçin</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-1">
                <label className="block text-white/60 text-xs font-bold uppercase tracking-wider mb-2">Tarih</label>
                <div className="relative">
                  <input 
                    type="date" 
                    className="input-dark w-full" 
                    value={date} 
                    onChange={(e) => setDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    data-testid="date-input"
                  />
                </div>
              </div>

              <div className="md:col-span-1 flex items-end">
                <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2" data-testid="search-btn">
                  <Search className="w-5 h-5" />
                  Sefer Ara
                </button>
              </div>
            </form>
          </div>

          {/* Quick Access */}
          {user && (
            <div className="mt-8 flex justify-center gap-4">
              <button 
                onClick={() => navigate(user.role === 'admin' ? '/admin/dashboard' : user.role === 'company' ? '/company/dashboard' : '/member/search')}
                className="btn-secondary"
                data-testid="dashboard-btn"
              >
                Panele Git
              </button>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default LandingPage;
